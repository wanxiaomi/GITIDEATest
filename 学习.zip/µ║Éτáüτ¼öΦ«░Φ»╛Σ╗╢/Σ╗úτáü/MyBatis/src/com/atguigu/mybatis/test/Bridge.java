package com.atguigu.mybatis.test;

public class Bridge {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Driver
		// ConnectionImpl
		
		
	}

}
