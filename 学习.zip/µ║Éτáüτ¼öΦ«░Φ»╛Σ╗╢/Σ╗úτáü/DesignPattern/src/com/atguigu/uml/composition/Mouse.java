package com.atguigu.uml.composition;

public class Mouse {

}
