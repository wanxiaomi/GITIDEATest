package com.atguigu.uml.generalization;

public abstract class DaoSupport{
	public void save(Object entity){
	}
	public void delete(Object id){
	}
}

