package com.atguigu.uml.dependence;

public class PersonServiceBean {
	private PersonDao personDao;// ��

	public void save(Person person) {
	}

	public IDCard getIDCard(Integer personid) {
		return null;
	}

	public void modify() {
		Department department = new Department();
	}

}
