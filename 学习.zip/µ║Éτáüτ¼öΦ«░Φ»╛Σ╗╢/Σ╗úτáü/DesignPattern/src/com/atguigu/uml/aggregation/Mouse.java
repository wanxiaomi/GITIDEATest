package com.atguigu.uml.aggregation;

public class Mouse {

}
