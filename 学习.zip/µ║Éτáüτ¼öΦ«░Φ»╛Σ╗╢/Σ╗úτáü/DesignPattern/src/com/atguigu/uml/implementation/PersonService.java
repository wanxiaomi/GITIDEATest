package com.atguigu.uml.implementation;

public interface PersonService {
	public void delete(Integer id);

}
