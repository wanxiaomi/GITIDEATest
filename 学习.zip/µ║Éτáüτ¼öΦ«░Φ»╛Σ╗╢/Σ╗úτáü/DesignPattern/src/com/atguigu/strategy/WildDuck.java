package com.atguigu.strategy;

public class WildDuck extends Duck {

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println(" ����ҰѼ ");
	}

}
