package com.atguigu.strategy.improve;

public class BadFlyBehavior implements FlyBehavior {

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		System.out.println(" ���輼��һ�� ");
	}

}
