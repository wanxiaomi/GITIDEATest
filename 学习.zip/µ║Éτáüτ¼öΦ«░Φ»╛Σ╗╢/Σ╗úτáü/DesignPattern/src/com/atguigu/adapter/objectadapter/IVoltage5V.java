package com.atguigu.adapter.objectadapter;


//����ӿ�
public interface IVoltage5V {
	public int output5V();
}
