package com.atguigu.bridge;

public class XiaoMi implements Brand {

	@Override
	public void open() {
		// TODO Auto-generated method stub
		System.out.println(" С���ֻ����� ");
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		System.out.println(" С���ֻ��ػ� ");
	}

	@Override
	public void call() {
		// TODO Auto-generated method stub
		System.out.println(" С���ֻ���绰 ");
	}

}
