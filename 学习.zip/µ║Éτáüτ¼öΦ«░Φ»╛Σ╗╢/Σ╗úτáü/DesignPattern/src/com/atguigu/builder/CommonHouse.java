package com.atguigu.builder;

public class CommonHouse extends AbstractHouse {

	@Override
	public void buildBasic() {
		// TODO Auto-generated method stub
		System.out.println(" ��ͨ���Ӵ�ػ� ");
	}

	@Override
	public void buildWalls() {
		// TODO Auto-generated method stub
		System.out.println(" ��ͨ������ǽ ");
	}

	@Override
	public void roofed() {
		// TODO Auto-generated method stub
		System.out.println(" ��ͨ���ӷⶥ ");
	}

}
