package com.atguigu.spring.test;

public class Command {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// JdbcTemplate 
	}

}
