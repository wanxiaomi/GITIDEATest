package com.luban.dao;

public interface Dao {
	public void query();
}
